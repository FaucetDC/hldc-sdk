//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CeApiSpy.rc
//
#define IDR_MENUBAR                     101
#define IDC_START                       40001
#define IDS_CAP_START                   40003
#define IDC_STOP                        40004
#define IDS_CAP_STOP                    40006
#define IDC_SAVE                        40007
#define IDS_CAP_SAVE                    40009
#define IDS_CAP_OK                      40011
#define IDC_OPTIONS                     40012
#define IDS_CAP_OPTIONS                 40014
#define IDC_TRACE_INTERCEPTED           40015
#define IDC_TRACE_SPY_BRIEF             40016
#define IDC_TRACE_SPY_DETAILED          40017
#define IDC_OUTPUT_MEM                  40018
#define IDC_OUTPUT_DEBUG                40019
#define IDC_DUMP_APIS                   40020
#define IDS_CAP_DUMP_APIS               40020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40023
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
