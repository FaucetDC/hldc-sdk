#if !defined ( PROCINFOH )
#define PROCINFOH
#pragma once

int		PROC_GetSpeed( void );
int		PROC_IsMMX( void );

#endif // PROCINFOH
