extern int stricmp(const char *a, const char *b);
extern int isspace(int character);
extern void *calloc(size_t nmemb, size_t size);